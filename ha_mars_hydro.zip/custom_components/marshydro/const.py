DOMAIN = "marshydro"
CONF_USERNAME = "username"
CONF_PASSWORD = "password"